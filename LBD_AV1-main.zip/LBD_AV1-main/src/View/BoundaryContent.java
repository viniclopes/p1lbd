package View;

import javafx.scene.layout.Pane;

public interface BoundaryContent {
	public Pane generateForm();
}
